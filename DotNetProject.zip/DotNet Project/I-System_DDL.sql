CREATE DATABASE NCSInventory2022
GO

USE NCSInventory2022

CREATE TABLE Products 
(ID int PRIMARY KEY,
name varchar(50) NOT NULL,
category varchar(50),
price float NOT NULL,
stock int NULL
);

CREATE TABLE Admin
(ID int PRIMARY KEY,
fullname varchar(50) NOT NULL,
login_username varchar(50) NOT NULL,
login_password varchar(50) NOT NULL,
email varchar(50) CHECK (email LIKE '%@%.%'),
reference_code varchar(10) NOT NULL,
DateOfJoining datetime DEFAULT GETDATE(),
Admin_Type varchar(10) NOT NULL,
);

CREATE TABLE [dbo].[ProductHistory] (
    [Id]                  INT          IDENTITY (1, 1) NOT NULL,
    [ProductId]           INT          NOT NULL,
    [Old_ProductName]     VARCHAR (50) NULL,
    [Old_ProductCategory] VARCHAR (50) NULL,
    [Old_ProductPrice]    FLOAT (53)   NULL,
    [Old_ProductStock]    INT          NULL,
    [New_ProductName]     VARCHAR (50) NULL,
    [New_ProductCategory] VARCHAR (50) NULL,
    [New_ProductPrice]    FLOAT (53)   NULL,
    [New_ProductStock]    INT          NULL,
    [Operations]          VARCHAR (50) NOT NULL,
    [MadeBy_AdminId]      INT          NOT NULL,
    [MadeBy_AdminName]    VARCHAR (50) NOT NULL,
    [Adjustment_DateTime] DATETIME     NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);


INSERT INTO Products VALUES
(001,'Bluetooth Headset','Mobile & Accessories',22.50,15),
(002,'Smarth Watch','Mobile & Accessories',75,10),
(003,'Pull Up Bar','Sports & Outdoor',18.50,35),
(004,'Fitness Yoga Ball','Sports & Outdoor',21.90,20),
(005,'Resistance Band','Sports & Outdoor',15.00,20),
(006,'Laptop Cooling Fan','Computer & Accessories',45.50,15),
(007,'Wireless Mouse','Computer & Accessories',50,50),
(008,'Leather Mousepad','Computer & Accessories',5,35),
(009,'Aluminium Headphone Stand','Mobile & Accessories',10.90,10),
(010,'Camping Tent','Sports & Outdoor',500,10);


INSERT INTO Admin VALUES 
(001,'GOH CHUN PIN','pin0818','NCS@2022','chunpin0818@outlook.com','qwerty',default,'MASTER');
