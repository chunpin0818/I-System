﻿using Inventory_Mangement_System.Models;
using System;
using System.Linq;
using System.Web.Mvc;

namespace Inventory_Mangement_System.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult LoginPage()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult LoginPage(Admin admin)
        {
            using (NCSInventory2022Entities3 mydb = new NCSInventory2022Entities3())
            {
                var myadmin = mydb.Admins.Where(ad => ad.login_username == admin.login_username && ad.login_password == admin.login_password).FirstOrDefault();
                if (myadmin != null)
                {
                    Session["ID"] = myadmin.ID;
                    Session["FullName"] = myadmin.fullname;
                    Session["Email"] = myadmin.email;
                    Session["AdminType"] = myadmin.Admin_Type;
                    return RedirectToAction("Index", "Products");
                }
                else
                {
                    ViewBag.Error = " [ Invalid Username or Password ! ] ";
                }
            }
            return View();
        }

        public ActionResult SignUp()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult SignUp(Admin newadmin)
        {
            using (NCSInventory2022Entities3 mydb = new NCSInventory2022Entities3())
            {
                var checkid = mydb.Admins.FirstOrDefault(s => s.ID == newadmin.ID);
                var checkusername = mydb.Admins.FirstOrDefault(s => s.login_username == newadmin.login_username);
                var checkreference = mydb.Admins.FirstOrDefault(s => s.reference_code == newadmin.reference_code);

                if (newadmin.login_password == newadmin.confirm_password)
                {
                    if (checkid == null)
                    {
                        if (checkusername == null)
                        {
                            if (checkreference != null && newadmin.reference_code != "N/A")
                            {
                                newadmin.DateOfJoining = DateTime.Now;
                                newadmin.reference_code = "N/A";
                                newadmin.Admin_Type = "REGULAR";
                                mydb.Admins.Add(newadmin);
                                mydb.SaveChanges();
                                return RedirectToAction("LoginPage", "Home");
                            }
                            else
                            {
                                ViewBag.error = " Reference Code is not Correct (You can obtain reference code from Admin)";
                            }
                        }
                        else
                        {
                            ViewBag.error = " [ Username Exists ! ]";
                        }
                    }
                    else
                    {
                        ViewBag.error = " [ Agent ID Exists ! ]";
                    }
                }
                else
                {
                    ViewBag.error = " [ Password Not Corrected ! ]";
                }



            }
            return View();
        }

        public ActionResult Logout()
        {
            Session.Clear();
            return RedirectToAction("LoginPage", "Home");
        }

    }
}