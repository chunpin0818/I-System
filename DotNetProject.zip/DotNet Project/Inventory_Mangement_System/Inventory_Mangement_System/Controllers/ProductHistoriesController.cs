﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Inventory_Mangement_System.Models;

namespace Inventory_Mangement_System.Controllers
{
    public class ProductHistoriesController : Controller
    {
        private NCSInventory2022Entities3 db = new NCSInventory2022Entities3();

        // GET: ProductHistories
        public ActionResult Index(string sortOrder, string searchString)
        {
            var producthistories = from s in db.ProductHistories
                           select s;

            //Search String
            if (!String.IsNullOrEmpty(searchString))
            {
                producthistories = producthistories.Where(s => s.Operations.Contains(searchString)
                                                        || s.MadeBy_AdminName.Contains(searchString));
            }

            //Sorting Order
            ViewBag.ProductIdSortParm = sortOrder == "Product Id" ? "Product Id_desc" : "Product Id";
            ViewBag.OperationsSortParm = sortOrder == "Operations" ? "Operations_desc" : "Operations";
            ViewBag.MadeByAdminIdSortParm = sortOrder == "MadeBy (Admin Id)" ? "MadeBy (Admin Id)_desc" : "MadeBy (Admin Id)";
            ViewBag.MadeByAdminNameSortParm = sortOrder == "MadeBy (Admin Name)" ? "MadeBy (Admin Name)_desc" : "MadeBy (Admin Name)";
            ViewBag.AdjustmentDateTimeSortParm = sortOrder == "Adjustment (Date&Time)" ? "Adjustment (Date&Time)_desc" : "Adjustment (Date&Time)";

            switch (sortOrder)
            {
                case "Product Id":
                    producthistories = producthistories.OrderBy(s => s.ProductId);
                    break;
                case "Product Id_desc":
                    producthistories = producthistories.OrderByDescending(s => s.ProductId);
                    break;
                case "Operations":
                    producthistories = producthistories.OrderBy(s => s.Operations);
                    break;
                case "Operations_desc":
                    producthistories = producthistories.OrderByDescending(s => s.Operations);
                    break;
                case "MadeBy (Admin Id)":
                    producthistories = producthistories.OrderBy(s => s.MadeBy_AdminId);
                    break;
                case "MadeBy (Admin Id)_desc":
                    producthistories = producthistories.OrderByDescending(s => s.MadeBy_AdminId);
                    break;
                case "MadeBy (Admin Name)":
                    producthistories = producthistories.OrderBy(s => s.MadeBy_AdminName);
                    break;
                case "MadeBy (Admin Name)_desc":
                    producthistories = producthistories.OrderByDescending(s => s.MadeBy_AdminName);
                    break;
                case "Adjustment (Date&Time)":
                    producthistories = producthistories.OrderBy(s => s.Adjustment_DateTime);
                    break;
                case "Adjustment (Date&Time)_desc":
                    producthistories = producthistories.OrderByDescending(s => s.Adjustment_DateTime);
                    break;
                default:
                    producthistories = producthistories.OrderBy(s => s.ProductId);
                    break;
            }
            return View(producthistories.ToList());
        }

        // GET: ProductHistories/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ProductHistory productHistory = db.ProductHistories.Find(id);
            if (productHistory == null)
            {
                return HttpNotFound();
            }
            return View(productHistory);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
