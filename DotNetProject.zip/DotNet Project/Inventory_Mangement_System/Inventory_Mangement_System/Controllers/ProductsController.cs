﻿using Inventory_Mangement_System.Models;
using System;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using PagedList;
using System.Collections.Generic;

namespace Inventory_Mangement_System.Controllers
{
    public class ProductsController : Controller
    {
        private NCSInventory2022Entities3 db = new NCSInventory2022Entities3();

        // GET: Products

        public ActionResult Index(string sortOrder,string searchString)
        {
            var products = from s in db.Products
                           select s;

            //Search String
            if (!String.IsNullOrEmpty(searchString))
            {
                products = products.Where(s => s.name.Contains(searchString)
                                        || s.category.Contains(searchString));
            }         

            //Sorting Order
            ViewBag.NameSortParm = sortOrder == "Name" ? "Name_desc" : "Name";
            ViewBag.CategorySortParm = sortOrder == "Category" ? "Category_desc" : "Category";
            ViewBag.PriceSortParm = sortOrder == "Price($)" ? "Price($)_desc" : "Price($)";
            ViewBag.StockSortParm = sortOrder == "Stock" ? "Stock_desc" : "Stock";

            switch (sortOrder)
            {
                case "Name":
                    products = products.OrderBy(s => s.name);
                    break;
                case "Name_desc":
                    products = products.OrderByDescending(s => s.name);
                    break;
                case "Category":
                    products = products.OrderBy(s => s.category);
                    break;
                case "Category_desc":
                    products = products.OrderByDescending(s => s.category);
                    break;
                case "Price($)":
                    products = products.OrderBy(s => s.price);
                    break;
                case "Price($)_desc":
                    products = products.OrderByDescending(s => s.price);
                    break;
                case "Stock":
                    products = products.OrderBy(s => s.stock);
                    break;
                case "Stock_desc":
                    products = products.OrderByDescending(s => s.stock);
                    break;
                default:
                    products = products.OrderBy(s => s.name);
                    break;
            }
            return View(products.ToList());

        }

        // GET: Products/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Product product = db.Products.Find(id);
            if (product == null)
            {
                return HttpNotFound();
            }
            return View(product);
        }

        // GET: Products/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Products/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ID,name,category,price,stock")] Product product)
        {
            if (ModelState.IsValid)
            {
                var checkProductID = db.Products.FirstOrDefault(ad => ad.ID == product.ID);
                if (checkProductID == null)
                {
                    if (product.name != null & product.category != null & product.price != null & product.stock != null)
                    {
                        ProductHistory newrecord = new ProductHistory()
                        {
                            ProductId = product.ID,
                            New_ProductName = product.name,
                            New_ProductCategory = product.category,
                            New_ProductPrice = product.price,
                            New_ProductStock = product.stock,
                            Operations = "CREATE",
                            MadeBy_AdminId = Convert.ToInt32(@Session["ID"]),
                            MadeBy_AdminName = @Session["FullName"].ToString(),
                            Adjustment_DateTime = DateTime.Now
                        };
                        db.ProductHistories.Add(newrecord);

                        db.Products.Add(product);
                        db.SaveChanges();
                        return RedirectToAction("Index");
                    }
                    else
                    {
                        ViewBag.Error = "[ Please Fill in All the Information ! ]";
                    }
                }
                else
                {
                    ViewBag.Error = "[ Product ID is Exists ! ]";
                }
            }
            return View(product);
        }

        // GET: Products/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Product product = db.Products.Find(id);
            if (product == null)
            {
                return HttpNotFound();
            }
            return View(product);
        }

        // POST: Products/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ID,name,category,price,stock")] Product product)
        {
            if (ModelState.IsValid)
            {
                if(product.name!=null & product.category != null & product.price != null & product.stock != null)
                {
                    NCSInventory2022Entities3 tempdb = new NCSInventory2022Entities3();
                    Product existedrecord = tempdb.Products.FirstOrDefault(p => p.ID == product.ID);
                    ProductHistory editedrecord = new ProductHistory()
                    {
                        ProductId = product.ID,
                        Old_ProductName = existedrecord.name,
                        Old_ProductCategory = existedrecord.category,
                        Old_ProductPrice = existedrecord.price,
                        Old_ProductStock = existedrecord.stock,
                        New_ProductName = product.name,
                        New_ProductCategory = product.category,
                        New_ProductPrice = product.price,
                        New_ProductStock = product.stock,
                        Operations = "EDIT",
                        MadeBy_AdminId = Convert.ToInt32(@Session["ID"]),
                        MadeBy_AdminName = @Session["FullName"].ToString(),
                        Adjustment_DateTime = DateTime.Now
                    };
                    db.ProductHistories.Add(editedrecord);


                    db.Entry(product).State = EntityState.Modified;
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }
                else
                {
                    ViewBag.Error = "[ Please Fill in All the Information ! ]";
                }
 
            }
            return View(product);
        }

        // GET: Products/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Product product = db.Products.Find(id);
            if (product == null)
            {
                return HttpNotFound();
            }
            return View(product);
        }

        // POST: Products/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Product product = db.Products.Find(id);
            ProductHistory deleterecord = new ProductHistory()
            {
                ProductId = product.ID,
                Old_ProductName = product.name,
                Old_ProductCategory = product.category,
                Old_ProductPrice = product.price,
                Old_ProductStock = product.stock,
                Operations = "DELETE",
                MadeBy_AdminId = Convert.ToInt32(@Session["ID"]),
                MadeBy_AdminName = @Session["FullName"].ToString(),
                Adjustment_DateTime = DateTime.Now
            };
            db.ProductHistories.Add(deleterecord);

            db.Products.Remove(product);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
