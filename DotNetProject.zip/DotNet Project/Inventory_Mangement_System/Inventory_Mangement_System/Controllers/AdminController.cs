﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Inventory_Mangement_System.Controllers
{
    public class AdminController : Controller
    {
        // GET: Admin
        public ActionResult LoginPage()
        {
            return View();
        }
        public ActionResult LoginPage(Admin admin)
        {
            NCSInventory2022Entities1 mydb = new NCSInventory2022Entities1();
            var myadmin = mydb.Admins.Where(ad => ad.login_username.Equals(admin.login_username) && ad.login_password.Equals(admin.login_password));
            if (myadmin != null)
            {
                return RedirectToAction("~/Views/Products/Index.cshtml");
            }

            return View("~/Views/Products/Index.cshtml");
        }
    }
}