﻿using Inventory_Mangement_System.Models;
using System;
using System.Data.Entity;
using System.Data.Linq;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Web.Mvc;

namespace Inventory_Mangement_System.Controllers
{
    public class AdminsController : Controller
    {
        private NCSInventory2022Entities3 db = new NCSInventory2022Entities3();

        // GET: Admins
        public ActionResult Index(string sortOrder, string searchString)
        {
            var admins = from s in db.Admins
                           select s;


            //Search String
            if (!String.IsNullOrEmpty(searchString))
            {
                admins = admins.Where(s => s.fullname.Contains(searchString)
                                        || s.Admin_Type.Contains(searchString)
                                        || s.email.Contains(searchString)
                                        || s.reference_code.Contains(searchString));
            }

            //Sorting Order
            ViewBag.FullNameSortParm = String.IsNullOrEmpty(sortOrder) ? "Full Name_desc" : "Full Name";
            ViewBag.EmailSortParm = sortOrder == "Email" ? "Email_desc" : "Email";
            ViewBag.ReferenceCodeSortParm = sortOrder == "Admin Reference Code" ? "Admin Reference Code_desc" : "Admin Reference Code";
            ViewBag.DateSortParm = sortOrder == "Date Of Joining" ? "Date Of Joining_desc" : "Date Of Joining";
            ViewBag.TypeSortParm = sortOrder == "Admin Type" ? "Admin Type_desc" : "Admin Type";

            switch (sortOrder)
            {
                case "Full Name_desc":
                    admins = admins.OrderByDescending(s => s.fullname);
                    break;
                case "Email":
                    admins = admins.OrderBy(s => s.email);
                    break;
                case "Email_desc":
                    admins = admins.OrderByDescending(s => s.email);
                    break;
                case "Admin Reference Code":
                    admins = admins.OrderBy(s => s.reference_code);
                    break;
                case "Admin Reference Code_desc":
                    admins = admins.OrderByDescending(s => s.reference_code);
                    break;
                case "Date Of Joining":
                    admins = admins.OrderBy(s => s.DateOfJoining);
                    break;
                case "Date Of Joining_desc":
                    admins = admins.OrderByDescending(s => s.DateOfJoining);
                    break;
                case "Admin Type":
                    admins = admins.OrderBy(s => s.Admin_Type);
                    break;
                case "Admin Type_desc":
                    admins = admins.OrderByDescending(s => s.Admin_Type);
                    break;
                default:
                    admins = admins.OrderBy(s => s.fullname);
                    break;
            }
            return View(admins.ToList());
        }


        // GET: Admins/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Admin admin = db.Admins.Find(id);
            if (admin == null)
            {
                return HttpNotFound();
            }
            return View(admin);
        }

        // GET: Admins/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Admins/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [HandleError]
        public ActionResult Create([Bind(Include = "ID,fullname,login_username,login_password,email,reference_code,DateOfJoining,Admin_Type")] Admin admin)
        {
            if (ModelState.IsValid)
            {
                var checkAdminID = db.Admins.FirstOrDefault(ad => ad.ID == admin.ID);
                if (checkAdminID == null)
                {
                    if (admin.fullname != null && admin.login_username != null && admin.login_password != null && admin.email != null && admin.Admin_Type != null && admin.DateOfJoining != null && admin.reference_code != null)
                    {
                        db.Admins.Add(admin);
                        db.SaveChanges();
                        return RedirectToAction("Index");
                    }
                    else
                    {
                        ViewBag.Error = "[ Please Fill in All the Information ! ]";
                    }
                }
                else
                {
                    ViewBag.Error = "[ Admin ID is Exists ! ]";
                }
            }
            return View(admin);
        }

        // GET: Admins/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Admin admin = db.Admins.Find(id);
            if (admin == null)
            {
                return HttpNotFound();
            }
            return View(admin);
        }

        // POST: Admins/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ID,fullname,login_username,login_password,email,reference_code,DateOfJoining,Admin_Type")] Admin admin)
        {
            if (ModelState.IsValid)
            {
                if (admin.fullname != null && admin.login_username != null && admin.login_password != null && admin.email != null && admin.Admin_Type != null && admin.DateOfJoining != null && admin.reference_code != null)
                {
                    db.Entry(admin).State = EntityState.Modified;
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }
                else
                {
                    ViewBag.Error = "[ Please Fill in All the Information ! ]";
                }

            }
            return View(admin);
        }

        // GET: Admins/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Admin admin = db.Admins.Find(id);
            if (admin == null)
            {
                return HttpNotFound();
            }
            return View(admin);
        }

        // POST: Admins/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Admin admin = db.Admins.Find(id);
            db.Admins.Remove(admin);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
